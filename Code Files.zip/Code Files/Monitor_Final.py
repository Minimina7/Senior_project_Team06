
# imports files 
from ultralytics import YOLO
import numpy as np
from collections import defaultdict
import cv2
import os
from email.message import EmailMessage
import ssl
import smtplib
import time
from io import BytesIO

model = YOLO('6495-R.pt')  # load a pretrained model (recommended for training)
cap = cv2.VideoCapture(0) #open the Camera connected to the device

# Needed time to send the notification message (10min for our project)
send_time = (60*10)

# Create a range for product IDs from 0 to 11
productIds = range(12) 


# an array contains the correct order of the products on the Shelves.
ProductsOrder = np.array([[6, 0, 3, 8], [11, 10, 5, 9], [4, 7, 2, 1]])

# Initialize timers to zero and flags to False for each product ID
# For the Empty Product function
# array contains the time that the product were absent 
EmptyProductsTimer = {id: 0 for id in productIds}
# array contains flags that indicate if the timer of the product in ON(True) or off(False)
TimerOnFlagsEmpty = {id: False for id in productIds}
# array contains flags that indicate a message has been sent to the employee
EmptyProductsFlags = {id: False for id in productIds}

# For the Misplaced Product function
# array contains the time that the product were misplaced on the shelf 
MisPlaceProductsTimer = {id: 0 for id in productIds}
# array contains flags that indicate if the timer of the product in ON(True) or off(False)
TimerOnFlagsEmptyMisplace = {id: False for id in productIds}
# array contains flags that indicate a message has been sent to the employee
MisplacedProductsFlag = {id: False for id in productIds}

# Check if the camera in connected or not
if not cap.isOpened():
     print("Cannot open camera")
     exit()

# this function to capture the last frame and convert the image to JPG
def capture_photo(frame):
    # Convert the image to JPEG format in memory
    is_success, buffer = cv2.imencode(".jpg", frame)
    if not is_success:
        print("Could not convert image to JPG")
        return None
    return BytesIO(buffer)

# Method to change the product order to the new order
def ProdectOrderGenEmpty(sorted):
    i = 0
    j = 0
    for result in sorted:
        ProductsOrder [i][j]= result[3]
        j = j + 1
        if j == 4:
            i = i + 1
            j = 0
# this function split the matrix
def MSplit(matrix, column_index):
    """
    Split a matrix into multiple matrices based on the difference between consecutive values
    in a specified column exceeding 30.
    
    Args:
    matrix (np.array): The input matrix to split.
    column_index (int): The index of the column to check for splits.
    
    Returns:
    list of np.array: A list of matrices split based on the specified condition.
    """
    splits = []
    start = 0
    for i in range(len(matrix) - 1):
        if abs(matrix[i, column_index] - matrix[i + 1, column_index]) > 30:
            splits.append(matrix[start:i + 1])
            start = i + 1
    splits.append(matrix[start:])
    return splits
# this function will check if the condition of sending notification is met or not.
def CanSendEmail(type, product_id):
    TimeNow = time.time() # current time 
    
    # case it is an empty product 
    # check if an email is already sent
    # check if the time is end 
    # check if the timer of the product is active
    if type == 1:
        if (EmptyProductsFlags[product_id] == True) or ((TimeNow - EmptyProductsTimer[product_id]) < send_time) or (TimerOnFlagsEmpty[product_id] == False):
            return False # No, you can't send an email 
        else:
            return True  # Yes, you can send an email

    # case it is an Misplaced product 
    # check if an email is already sent
    # check if the time is end 
    # check if the timer of the product is active 
    if type == 2:
        if (MisplacedProductsFlag[product_id] == True) or((TimeNow - MisPlaceProductsTimer[product_id]) < send_time) or (TimerOnFlagsEmptyMisplace[product_id] == False):
            return False # No, you can't send an email
        else:
            return True  # Yes, you can send an email
        
# this function set the time of the product 
def update_timer_on_detection(product_id, case):
    
    # case it is an empty product
    if case == 1: 
        # Update the timer when a product is detected in its correct place.
        EmptyProductsTimer[product_id] = time.time()
    
    # case it is an misplaced product
    if case == 2:
        # Update the timer when a product is detected in its correct place.
        MisPlaceProductsTimer[product_id] = time.time()
  
# this function to send the email
def SendEmail(id , case, frame ):
    # take the last frame as a photo and included in the email
    photo_io = capture_photo(frame)
    if photo_io is None:
        return "Failed to capture photo. Email not sent."
    # check first if the condition of sending notification is met or not 
    em = EmailMessage()
    if CanSendEmail(case, id) == True:
        
        email_sender = 'monitoringshelf@gmail.com'
        email_pass = 'mppo fjla vibt flal'
        email_rec = 'moayad1019p@gmail.com' # email for the receiver

        # check the product ID
        if id == 0:
            Pname = 'Chilli Chips'
            comp = 'Albatal'
        elif id == 1:
            Pname = 'Cookies'
            comp = 'Delights'
        elif id == 2:
            Pname = 'FullFat Milk'
            comp = 'Almarai'
        elif id == 3:
            Pname = 'Ketchup Chips'
            comp = 'Albatal'
        elif id == 4:
            Pname = 'LowFat Milk'
            comp = 'Almarai'
        elif id == 5:
            Pname = 'Peeled'
            comp = 'Nada'
        elif id == 6:
            Pname = 'PennePasta'
            comp = 'Goody'
        elif id == 7:
            Pname = 'PuffPastry'
            comp = 'Lulu'
        elif id == 8:
            Pname = 'Salt Chips'
            comp = 'Albatal'
        elif id == 9:
            Pname = 'Stevia'
            comp = 'steviana'
        elif id == 10:
            Pname = 'Tea'
            comp = 'rabea'
        else:
            Pname = 'Tuna'
            comp = 'Almawasim'
        
        # The email for empty detection
        if case == 1:
            TimerOnFlagsEmpty[id] = False # reset the timer flag to make timer not active 
            EmptyProductsFlags[id] = True # rise flag that indicate the email is sent 
            subject = 'Missing Product on the shelf!'

            body = """
Dear Product Manager,
I hope this message finds you well.
I am reaching out to bring to your attention that the Product [ {} ] from the company [ {} ] with ID number [ {} ],  is currently missing from its designated space on the shelf. I kindly request your immediate attention to restock the shelf with the product.
Thank you for your dedication to maintaining our product standards.

Best regards,
Monitoring Shelf AI
            """.format(Pname,comp,id)
        # The email for misplaced detection
        elif case == 2:
            TimerOnFlagsEmptyMisplace[id] = False # reset the timer flag to make timer not active 
            MisplacedProductsFlag[id] = True # rise flag that indicate the email is sent 
            subject = 'Missed placed product on the shelf!'

            body = """
Dear Product Manager,
I hope this message finds you well.
I am reaching out to bring to your attention that the Product [ {} ] from the company [ {} ] with ID number [ {} ],  is currently in the wrong place on the shelf. I kindly request your immediate attention to return the product on the right place.
Thank you for your dedication to maintaining our product standards.
    
Best regards,
Monitoring Shelf AI
            """.format(Pname,comp,id)

        
        em['From'] = email_sender
        em['To'] = email_rec
        em['Subject'] = subject
        em.set_content(body)

        # Attach the last frame photo
        photo_io.seek(0)
        em.add_attachment(photo_io.read(), maintype='image', subtype='jpeg', filename='webcam_photo.jpg')

        # Attach the products photo
        if id == 0:
            photo_filename = 'PP0.jpeg'
            with open(photo_filename, 'rb') as photo_file:
                photo_data = photo_file.read()
                em.add_attachment(photo_data, maintype='image', subtype='jpeg', filename=os.path.basename(photo_filename))

        if id == 1:
            photo_filename = 'PP1.jpeg'
            with open(photo_filename, 'rb') as photo_file:
                photo_data = photo_file.read()
                em.add_attachment(photo_data, maintype='image', subtype='jpeg', filename=os.path.basename(photo_filename))

        if id == 2:
            photo_filename = 'PP2.jpeg'
            with open(photo_filename, 'rb') as photo_file:
                photo_data = photo_file.read()
                em.add_attachment(photo_data, maintype='image', subtype='jpeg', filename=os.path.basename(photo_filename))

        if id == 3:
            photo_filename = 'PP3.jpeg'
            with open(photo_filename, 'rb') as photo_file:
                photo_data = photo_file.read()
                em.add_attachment(photo_data, maintype='image', subtype='jpeg', filename=os.path.basename(photo_filename))

        if id == 4:
            photo_filename = 'PP4.jpeg'
            with open(photo_filename, 'rb') as photo_file:
                photo_data = photo_file.read()
                em.add_attachment(photo_data, maintype='image', subtype='jpeg', filename=os.path.basename(photo_filename))

        if id == 5:
            photo_filename = 'PP5.jpeg'
            with open(photo_filename, 'rb') as photo_file:
                photo_data = photo_file.read()
                em.add_attachment(photo_data, maintype='image', subtype='jpeg', filename=os.path.basename(photo_filename))

        if id == 6:
            photo_filename = 'PP6.jpeg'
            with open(photo_filename, 'rb') as photo_file:
                photo_data = photo_file.read()
                em.add_attachment(photo_data, maintype='image', subtype='jpeg', filename=os.path.basename(photo_filename))

        if id == 7:
            photo_filename = 'PP7.jpeg'
            with open(photo_filename, 'rb') as photo_file:
                photo_data = photo_file.read()
                em.add_attachment(photo_data, maintype='image', subtype='jpeg', filename=os.path.basename(photo_filename))

        if id == 8:
            photo_filename = 'PP8.jpeg'
            with open(photo_filename, 'rb') as photo_file:
                photo_data = photo_file.read()
                em.add_attachment(photo_data, maintype='image', subtype='jpeg', filename=os.path.basename(photo_filename))

        if id == 9:
            photo_filename = 'PP9.jpeg'
            with open(photo_filename, 'rb') as photo_file:
                photo_data = photo_file.read()
                em.add_attachment(photo_data, maintype='image', subtype='jpeg', filename=os.path.basename(photo_filename))

        if id == 10:
            photo_filename = 'PP10.jpeg'
            with open(photo_filename, 'rb') as photo_file:
                photo_data = photo_file.read()
                em.add_attachment(photo_data, maintype='image', subtype='jpeg', filename=os.path.basename(photo_filename))

        if id == 11:
            photo_filename = 'PP11.jpeg'
            with open(photo_filename, 'rb') as photo_file:
                photo_data = photo_file.read()
                em.add_attachment(photo_data, maintype='image', subtype='jpeg', filename=os.path.basename(photo_filename))



        context1 = ssl.create_default_context()

        with smtplib.SMTP_SSL('smtp.gmail.com',465,context=context1) as smtp:
            smtp.login(email_sender,email_pass)
            smtp.sendmail(email_sender,email_rec, em.as_string())
     
# this function assign the product in the array according to there place on shelf 
def ShelfOrders(array, CenterX, CenterY, ID,sorted_results):
    # assign the product in its place depend on the region 
    if sorted_results[0][4]<=CenterX  and sorted_results[0][5]>=CenterX and sorted_results[0][1]<=CenterY and sorted_results[0][2]>=CenterY:
        if array[0,0] == -1:
            array[0,0] = ID
        elif array[0,0] == ProductsOrder[0,0]:
            array[0,0] = ID
    if sorted_results[0][5]<=CenterX  and sorted_results[1][5]>=CenterX and sorted_results[0][1]<=CenterY and sorted_results[0][2]>=CenterY :
        if array[0,1] == -1:
            array[0,1] = ID
        elif array[0,1] == ProductsOrder[0,1]:
            array[0,1] = ID
    if sorted_results[1][5]<=CenterX  and sorted_results[2][5]>=CenterX and sorted_results[0][1]<=CenterY and sorted_results[0][2]>=CenterY :
        if array[0,2] == -1:
            array[0,2] = ID
        elif array[0,2] == ProductsOrder[0,2]:
            array[0,2] = ID
    if sorted_results[2][5]<=CenterX and sorted_results[3][5]>=CenterX and sorted_results[0][1]<=CenterY and sorted_results[0][2]>=CenterY :
        if array[0,3] == -1:
            array[0,3] = ID
        elif array[0,3] == ProductsOrder[0,3]:
            array[0,3] = ID
    if sorted_results[4][4]<=CenterX  and sorted_results[4][5]>=CenterX  and sorted_results[4][1]<=CenterY and sorted_results[4][2]>=CenterY :
        if array[1,0] == -1:
            array[1,0] = ID
        elif array[1,0] == ProductsOrder[1,0]:
            array[1,0] = ID
    if sorted_results[4][5]<=CenterX and sorted_results[5][5]>=CenterX and sorted_results[4][1]<=CenterY and sorted_results[4][2]>=CenterY :
        if array[1,1] == -1:
            array[1,1] = ID
        elif array[1,1] == ProductsOrder[1,1]:
            array[1,1] = ID
    if sorted_results[5][5]<=CenterX and sorted_results[6][5]>=CenterX and sorted_results[4][1]<=CenterY and sorted_results[4][2]>=CenterY :
        if array[1,2] == -1:
            array[1,2] = ID
        elif array[1,2] == ProductsOrder[1,2]:
            array[1,2] = ID
    if sorted_results[6][5]<=CenterX and sorted_results[7][5]>=CenterX and sorted_results[4][1]<=CenterY and sorted_results[4][2]>=CenterY :
        if array[1,3] == -1:
            array[1,3] = ID
        elif array[1,3] == ProductsOrder[1,3]:
            array[1,3] = ID
    if sorted_results[8][4]<=CenterX and sorted_results[8][5]>=CenterX and sorted_results[9][1]<=CenterY and sorted_results[9][2]>=CenterY :
        if array[2,0] == -1:
            array[2,0] = ID
        elif array[2,0] == ProductsOrder[2,0]:
            array[2,0] = ID
    if sorted_results[8][5]<=CenterX and sorted_results[9][5]>=CenterX and sorted_results[9][1]<=CenterY and sorted_results[9][2]>=CenterY :
        if array[2,1] == -1:
            array[2,1] = ID
        elif array[2,1] == ProductsOrder[2,1]:
            array[2,1] = ID
    if sorted_results[9][5]<=CenterX and sorted_results[10][5]>=CenterX and sorted_results[9][1]<=CenterY and sorted_results[9][2]>=CenterY :
        if array[2,2] == -1:
            array[2,2] = ID
        elif array[2,2] == ProductsOrder[2,2]:
            array[2,2] = ID
    if sorted_results[10][5]<=CenterX and sorted_results[11][5]>=CenterX and sorted_results[9][1]<=CenterY and sorted_results[9][2]>=CenterY :
        if array[2,3] == -1:
            array[2,3] = ID
        elif array[2,3] == ProductsOrder[2,3]:
            array[2,3] = ID
        
# this function compare the the order of the shelf with the Real order       
def MisplacedProductDetection(RealOrder, shelforder,frame ):
     for i in range(3):  # Loop through each row
        for j in range(4):  # Loop through each column
            if RealOrder[i][j] != shelforder[i][j]:
                if shelforder[i][j] >= 0 : #skip if it -1 where it mean the product not exist 
                    if TimerOnFlagsEmptyMisplace[shelforder[i][j]] == False: # check if the timer is already active
                        update_timer_on_detection(shelforder[i][j],2) # Start the timer 
                        TimerOnFlagsEmptyMisplace[shelforder[i][j]] = True # rise the product timer flag
                    SendEmail(shelforder[i][j],2,frame) # ask SendEmail function to send an email
            else:
                TimerOnFlagsEmptyMisplace[shelforder[i][j]] = False # reset the timer flag
                MisplacedProductsFlag[shelforder[i][j]] = False # reset the misplacement flag
                      
# this function Detect the empty product                
def EmptyProductDetection(ProductsOrder, EmptyShelves,frame):
    for i in range(3):  # Loop through each row
        for j in range(4):  # Loop through each column
            if EmptyShelves[i][j] == -1 : # [-1] the product is empty
                if TimerOnFlagsEmpty[ProductsOrder[i][j]] == False: # check if the timer is already active
                    update_timer_on_detection(ProductsOrder[i][j],1) # Start the timer 
                    TimerOnFlagsEmpty[ProductsOrder[i][j]] = True # rise the product timer flag 
                SendEmail( ProductsOrder[i][j],1,frame) # ask SendEmail function to send an email

#this function attend the product in matrix
# if the product exist then the id of the product will be assign in the matrix if not then -1 
def EmptyShelfCheck(EmptyShelves,ProductID ,sorted):
    # for each ProductID 
        # attend the product on the EmptyShelves matrix 
        # Reset the Empty product flag 
        # Reset the Timer On Flags Empty
    for i in range(3):  # Loop through each row
        for j in range(4):  # Loop through each column:
            if ProductID == sorted[i][j]: # [-1] the product is empty
                EmptyShelves[i][j] = 1
                EmptyProductsFlags[ProductID] = False
                TimerOnFlagsEmpty[ProductID] = False 

        
frame_count = 0
# Load a model
# Use a raw string for the file path or double backslashes
while True:
    #Capture frame-by-frame
    ret, frame = cap.read()
    print(f'frame shape: {frame.shape}')

		
    # Check if frame is read correctly
    if not ret:
        print("Can't receive frame (stream end?). Exiting ...")
        break
        # Display the resulting frame
    
    results = model.predict(frame, show = True  , conf = 0.5, show_labels = False, show_conf = True , vid_stride	= 1 , device = 'cpu' )

    np.set_printoptions(suppress=True, precision=2)

    for result in results:
        boxes = result.boxes.data
    # print(boxes)
    if frame_count < 10:
        print('Calculating the bounding boxes for the products')
        print('frame_count:',frame_count)
        sorted_matrix = boxes.numpy()[boxes.numpy()[:, 1].argsort()] # Sort the matrix from lowest to highest in the second column
        split_matrices = MSplit(sorted_matrix, 1) # split the matrix to three matrixes
        results = []

        for idx, mat in enumerate(split_matrices):
            sorted_mat = mat[mat[:, 0].argsort()]  # Sorting each split matrix by the first column
            min_second_column = np.min(sorted_mat[:, 1])
            max_fourth_column = np.max(sorted_mat[:, 3])
            
            # Handling repeated values in the last column
            unique_last_column_values = np.unique(sorted_mat[:, -1])
            for value in unique_last_column_values:
                rows_with_value = sorted_mat[sorted_mat[:, -1] == value]
                min_first_column = np.min(rows_with_value[:, 0])
                max_third_column = np.max(rows_with_value[:, 2])
                
                # Storing the results in a list
                results.append((idx + 1, min_second_column, max_fourth_column, value, min_first_column, max_third_column))

        # Sorting the results by the split matrix index and the min value of the first column
        sorted_results = sorted(results, key=lambda x: (x[0], x[4]))
        ProdectOrderGenEmpty(sorted_results) # Take the new product orders

    if frame_count > 10:
        print('The Program has started to work on the Products')
    # an array contains the order of the products on the shelf
        ShelvesOrder = np.array([[-1, -1, -1, -1], [-1, -1, -1, -1], [-1, -1, -1, -1]])
        
        # an array contains an element for each product (Used for Empty product).
        EmptyShelves = np.array([[-1, -1, -1, -1], [-1, -1, -1, -1], [-1, -1, -1, -1]])


        for i in boxes.numpy():
            # for each Row in matrix boxes 
            # Boxes Rows contains [Xmin, Ymin, Xmax, Ymax, Confidence, productID]
            
            # Empty product detection 
            EmptyShelfCheck(EmptyShelves,i[5],ProductsOrder)
            
            # Misplaced product detection
            #Calculate the center of the products (needed for )
            CenterX = (((i[2])-i[0])/2) + i[0]
            CenterY = (((i[3])-i[1])/2) + i[1]
            ShelfOrders(ShelvesOrder,CenterX,CenterY, i[5],sorted_results)

        print(ShelvesOrder)
        print(EmptyShelves)

        #check the empty products on the shelf
        EmptyProductDetection(ProductsOrder,EmptyShelves,frame)

        #check the misplaced products on the shelf
        MisplacedProductDetection(ProductsOrder, ShelvesOrder,frame)
    
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
    frame_count = frame_count + 1
cap.release()
cv2.destroyAllWindows()